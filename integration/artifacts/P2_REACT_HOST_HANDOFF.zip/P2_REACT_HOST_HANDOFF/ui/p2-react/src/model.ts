import type {
  JsonRecord,
  P2EvidenceEnvelope,
  P2Journey,
  P2PanelModels,
  P2Population,
  P2RouteVariant,
  P2SourceReference,
} from "./types.js";

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function records(value: unknown): JsonRecord[] {
  return Array.isArray(value) ? value.filter(isRecord) : [];
}

function strings(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string") : [];
}

function getJourneyTransformation(value: unknown): JsonRecord | null {
  return records(value).find(item => item.id === "p2-journey-and-route-variants-v1") ?? null;
}

function getSnapshot(value: unknown): JsonRecord | null {
  return records(value).find(item => item.kind === "investigation_snapshot") ?? null;
}

function readJourneys(value: JsonRecord | null): P2Journey[] {
  if (!value) return [];
  return records(value.journeys).filter(item =>
    typeof item.wafer_id === "string" && typeof item.history_status === "string"
    && typeof item.route_conformance === "string" && Array.isArray(item.steps)
    && item.steps.every(step => isRecord(step) && typeof step.step_instance_id === "string"),
  ) as P2Journey[];
}

function readRoutes(value: JsonRecord | null): P2RouteVariant[] {
  if (!value) return [];
  return records(value.route_variants).filter(item =>
    typeof item.count === "number" && Array.isArray(item.operations)
    && item.operations.every(operation => typeof operation === "string")
    && Array.isArray(item.wafer_ids) && item.wafer_ids.every(wafer => typeof wafer === "string")
    && typeof item.order_status === "string",
  ) as P2RouteVariant[];
}

function readSources(value: unknown): P2SourceReference[] {
  return records(value).flatMap(item => {
    if (typeof item.id !== "string" || typeof item.approved_semantic_version !== "string"
        || typeof item.grain !== "string" || typeof item.source_hash !== "string") return [];
    return [{
      id: item.id,
      approved_semantic_version: item.approved_semantic_version,
      grain: item.grain,
      source_hash: item.source_hash,
      ...(typeof item.permissions_ref === "string" ? { permissions_ref: item.permissions_ref } : {}),
      ...(typeof item.observed_at === "string" ? { observed_at: item.observed_at } : {}),
    }];
  });
}

function readPopulations(value: unknown): P2Population[] {
  return records(value).filter(item =>
    typeof item.classification === "string" && typeof item.count === "number"
    && Array.isArray(item.wafer_ids) && typeof item.basis === "string",
  ) as P2Population[];
}

function requireEvidenceEnvelope(value: unknown): asserts value is P2EvidenceEnvelope {
  if (!isRecord(value) || value.schema_version !== "1.0.0" || value.product_id !== "p2"
      || typeof value.investigation_id !== "string"
      || !["VALID", "PARTIAL", "INCONCLUSIVE", "REFUSED", "ERROR"].includes(String(value.status))
      || !["SYNTHETIC_DEMO", "INTERNAL_AUTHORIZED"].includes(String(value.mode))
      || !Array.isArray(value.claims) || !value.claims.every(claim => isRecord(claim)
        && typeof claim.statement === "string" && typeof claim.category === "string"
        && Array.isArray(claim.source_ids) && typeof claim.method === "string" && typeof claim.certainty === "string")
      || !Array.isArray(value.sources) || !value.sources.every(source => isRecord(source)
        && typeof source.id === "string" && typeof source.approved_semantic_version === "string"
        && typeof source.grain === "string" && typeof source.source_hash === "string")
      || !Array.isArray(value.assumptions) || !Array.isArray(value.limitations)
      || !isRecord(value.provenance) || typeof value.provenance.input_sha256 !== "string") {
    throw new TypeError("A contract-v1 P2 evidence envelope is required.");
  }
}

/** Build typed, read-only panel models without adding joins or changing evidence. */
export function buildP2PanelModels(value: unknown): P2PanelModels {
  requireEvidenceEnvelope(value);
  const journey = getJourneyTransformation(value.transformations);
  const snapshot = getSnapshot(value.artifacts);
  const snapshotJourney = isRecord(snapshot?.journey) ? snapshot.journey : null;
  const sourceJourney = journey ?? snapshotJourney;
  const exposureTransform = records(value.transformations).find(item => item.id === "p2-exposure-evidence-v1");
  const analysis = isRecord(snapshot?.exposure_analysis)
    ? snapshot.exposure_analysis
    : (isRecord(exposureTransform?.exposure) ? exposureTransform.exposure : null);
  const uncertainty = isRecord(value.uncertainty) ? value.uncertainty : {};

  return {
    summary: {
      status: value.status,
      mode: value.mode,
      investigation_id: value.investigation_id,
      claims: value.claims,
      limitations: value.limitations,
    },
    journey: {
      transformation: journey,
      journeys: readJourneys(sourceJourney),
      route_variants: readRoutes(sourceJourney),
      route_population_summary: sourceJourney && isRecord(sourceJourney.route_population_summary)
        ? sourceJourney.route_population_summary : null,
    },
    exposure: {
      populations: readPopulations(value.populations),
      analysis,
    },
    counterevidence: { investigations: records(value.counterevidence) },
    evidence: {
      sources: readSources(value.sources),
      snapshot,
      uncertainty,
      limitations: strings(value.limitations),
      input_sha256: value.provenance.input_sha256,
    },
  };
}
